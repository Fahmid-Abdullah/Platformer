using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class attackCircle1 : MonoBehaviour
{
    logicScript logic;
    public float attackRate;
    public GameObject playerBody;
    
    // Start is called before the first frame update
    void Start()
    {
        logic = FindObjectOfType<logicScript>();
    }
    
    private void OnTriggerEnter2D(Collider2D collision) { 
        if (collision.gameObject.layer == 6) {
            InvokeRepeating("waitingAttack", 0.0f, attackRate);
        }
    }

    private void OnTriggerExit2D(Collider2D collision) {
        if (collision.gameObject.layer == 6) {
            CancelInvoke();
        }
        
    }

    private void waitingAttack() {
        logic.loseLife();
    }


}

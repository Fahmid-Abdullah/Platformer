using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moonSpawner : MonoBehaviour
{
    public GameObject moonEnemy;
    public GameObject[] spawnLocation;
    private int i;
    private int nP;
    private int spawnIndexP;
    

    public void spawnMoonEnemy(int n, int spawnIndex) {
        spawnIndexP = spawnIndex;
        nP = n;
        StartCoroutine(beforeNextSpawn());        
    }
    IEnumerator beforeNextSpawn(){
        while (i<nP) {
        Instantiate(moonEnemy, spawnLocation[spawnIndexP].transform.position, Quaternion.identity);
        i++;
        yield return new WaitForSeconds(0.5f);
        }
        i=0;
        StopAllCoroutines();

    }
}

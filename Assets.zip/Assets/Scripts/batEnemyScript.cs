using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class batEnemyScript : MonoBehaviour
{
    playerScript player;
    trapScript trap;
    public float speed;
    private int batCount;
    private bool isAttacking = true;
    private AudioSource source;

    
    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<playerScript>();
        trap = FindObjectOfType<trapScript>();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, new Vector2(player.transform.position.x,player.transform.position.y), speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if ((collision.gameObject.layer == 7) && isAttacking) {
            source.Play();
            waitBeforeNextAttack();
        }
    }

    private void waitBeforeNextAttack(){
        isAttacking = false;
        trap.batKills();
        Destroy(gameObject);
    }


}

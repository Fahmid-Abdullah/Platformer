using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class endGameScript : MonoBehaviour
{
    private void OnTriggerExit2D(Collider2D collision) { 
        Application.Quit();
    }
}

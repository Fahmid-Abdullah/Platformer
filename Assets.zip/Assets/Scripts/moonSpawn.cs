using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moonSpawn : MonoBehaviour
{

    moonSpawner mS;
    public int spawnCount;
    public int spawnIndex;

    void Update() {
        mS = FindObjectOfType<moonSpawner>();
    }
    
    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.layer == 6) {
            mS.spawnMoonEnemy(spawnCount, spawnIndex);
            gameObject.SetActive(false);
        }
    }
}

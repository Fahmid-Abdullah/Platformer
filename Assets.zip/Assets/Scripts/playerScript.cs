using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerScript : MonoBehaviour
{

    public float jumpForce;
    
    public Transform groundPos;
    private bool isGrounded;
    public float checkRadius;
    public LayerMask whatIsGround;

    private float jumpTimeCounter;
    public float jumpTime;
    private bool isJumping;

    private Rigidbody2D myRigidBody;
    public float runSpeed;
    public GameObject body;
    
    private Animator anim;
    public GameObject swordHitBox;

    private AudioSource source;

    // Start is called before the first frame update
    void Start()
    {
        myRigidBody = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

        if ((Input.GetKeyDown(KeyCode.Space))) {
            StartCoroutine(attack());
        }



        isGrounded = Physics2D.OverlapCircle(groundPos.position, checkRadius, whatIsGround);

        if (isGrounded && Input.GetKeyDown(KeyCode.UpArrow)) {
            anim.SetTrigger("takeOff");
            isJumping = true;
            jumpTimeCounter = jumpTime;
            myRigidBody.velocity = Vector2.up * jumpForce;
        }

        if (isGrounded == true) {
            anim.SetBool("isJumping", false);
        } else {
            anim.ResetTrigger("takeOff");
            anim.SetBool("isJumping", true);
        }

        if (Input.GetKey(KeyCode.UpArrow) && isJumping) {
            if (jumpTimeCounter > 0) {
                myRigidBody.velocity = Vector2.up * jumpForce;
                jumpTimeCounter -= Time.deltaTime;
            } else {
                isJumping = false;
            }
            
        }

        if (Input.GetKeyUp(KeyCode.UpArrow) && isJumping == true) {
            isJumping = false;
            }
        

        float moveInput = Input.GetAxisRaw("Horizontal");
        myRigidBody.velocity = new Vector2(moveInput * runSpeed, myRigidBody.velocity.y);

        if (moveInput == 0) {
            anim.SetBool("isRunning", false);
        } else {
            anim.SetBool("isRunning", true);

            if (moveInput < 0) {
                body.transform.eulerAngles = new Vector3(0, 180, 0);
            } else if (moveInput > 0) {
                body.transform.eulerAngles = new Vector3(0, 0, 0);
            }
                }
            }

    IEnumerator attack() {
        source.Play();
        swordHitBox.SetActive(true);
        anim.SetTrigger("attack");
        yield return new WaitForSeconds(0.3f);
        swordHitBox.SetActive(false);
    }


}

    
    


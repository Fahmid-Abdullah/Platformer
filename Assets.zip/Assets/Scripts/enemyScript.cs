using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyScript : MonoBehaviour
{
    playerScript player;
    public float speed;
    public int moonEnemyHealth;
    private bool isAttacking = true;
    public float timeBeforeNextDamage;
    private AudioSource source;
    
    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<playerScript>();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, new Vector2(player.transform.position.x,player.transform.position.y), speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision) { 
        if ((collision.gameObject.layer == 7) && isAttacking) {
            StartCoroutine(waitBeforeNextAttack());
        }
    }


    IEnumerator waitBeforeNextAttack(){
        isAttacking = false;
        source.Play();
        if (moonEnemyHealth == 0) {
            Destroy(gameObject);
        }
        moonEnemyHealth--;
        yield return new WaitForSeconds(timeBeforeNextDamage);
        isAttacking = true;
    }

    
}

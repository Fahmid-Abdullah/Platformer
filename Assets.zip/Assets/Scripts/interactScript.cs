using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class interactScript : MonoBehaviour
{
   private logicScript logic;
   public GameObject bunnyText;
   private AudioSource source;
   
    // Start is called before the first frame update
    void Start()
    {
        logic = GetComponent<logicScript>();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.layer == 6) {
            bunnyText.SetActive(true);
            source.Play();
        }
     }

    private void OnTriggerExit2D(Collider2D collision) {
        if (collision.gameObject.layer == 6) {
            bunnyText.SetActive(false);
        }
} 
}

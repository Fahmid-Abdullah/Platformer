using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trapScript : MonoBehaviour
{
    batEnemyScript bat;

    public GameObject treasureClosed;
    public GameObject treasureOpened;
    public GameObject treasureMessage;
    public GameObject treasureMessageEnd;
    public GameObject treasureWalls;
    public GameObject batEnemy;
    public GameObject treasureNotOpened;

    public Transform[] spawnPoints;
    public float timeBetweenSpawns;
    private bool executeOnce = true;
    private int totalBats;
    private int batCount;

    private AudioSource source;

    // Start is called before the first frame update
    void Start()
    {
        bat = FindObjectOfType<batEnemyScript>();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (totalBats > 15) {
            CancelInvoke();
        }
        if (batCount >= 15) {
            missionComplete();
        }
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if ((collision.gameObject.layer == 7) && executeOnce) {
            StartCoroutine(waitSeconds());
        }
    }

    private void spawnBat(){
        Instantiate(batEnemy, spawnPoints[Random.Range(0, spawnPoints.Length)].position, Quaternion.identity);
        totalBats++;
    }

    IEnumerator waitSeconds() {
        executeOnce = false;
        source.Play();
        treasureClosed.SetActive(false);
        treasureOpened.SetActive(true);
        treasureMessage.SetActive(true);
        treasureNotOpened.SetActive(false);
        treasureWalls.SetActive(true);
        yield return new WaitForSeconds(7.0f);
        treasureMessage.SetActive(false);
        InvokeRepeating("spawnBat", 0.0f, timeBetweenSpawns);
    }

    public void missionComplete() {
        treasureOpened.SetActive(false);
        treasureClosed.SetActive(true);
        treasureMessageEnd.SetActive(true);
        treasureWalls.SetActive(false);
    }

    public void batKills() {
        batCount++;
    }
}
